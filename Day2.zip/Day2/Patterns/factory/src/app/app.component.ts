import {Component, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {ChildComponent} from "./child/child.component";
import {AnotherChildComponent} from "./another-child/another-child.component";
 
@Component({
 selector: 'app-root',
 templateUrl: 'app.component.html',
 styleUrls: ['app.component.css']
})
export class AppComponent {
 
 title = 'app works!';
 
 @ViewChild('parent', {read: ViewContainerRef})
 parent: ViewContainerRef;
 
 constructor (private componentFactoryResolver: ComponentFactoryResolver) {
 const childComponent = this.componentFactoryResolver.resolveComponentFactory(ChildComponent); 
 const anotherChildComponent = this.componentFactoryResolver.resolveComponentFactory(AnotherChildComponent)
 
 setTimeout(()=>{
 // at this point we want the "child" component to be rendered into the app.component:
  this.parent.createComponent(childComponent);
 
 setTimeout(()=>{
 // at this point we want the "another-child" component to be rendered into the app.component:
 this.parent.createComponent(anotherChildComponent);
 
 }, 1000);
 }, 1000);
 }
}