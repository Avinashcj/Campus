import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-another-child',
  templateUrl: './another-child.component.html',
  styleUrls: ['./another-child.component.css']
})
export class AnotherChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
