import  { Singleton } from './Singleton'

   function show() : void {
        var singleton1 = Singleton.Instance;
	var singleton2 = Singleton.Instance;
 
	if (singleton1 === singleton2) {
	    console.log("two singletons are equivalent");
	} else {
	    console.log("two singletons are not equivalent");
	}
    	}
    show();
