import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h3>Routing Application</h3>
              `,
})
export class AppComponent 
{
   
}
