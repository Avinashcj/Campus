import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee-list.component';
import { DepartmentListComponent } from './department-list.component';


@NgModule({
    imports:      [ BrowserModule ],
  declarations: [ AppComponent,EmployeeListComponent,DepartmentListComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
