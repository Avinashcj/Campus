import {Component} from '@angular/core';

@Component({
     template: `<h1>Contact Us</h1>
                <h3>Mohammad Tufail Ahmed </h3>
                <h3>tufailahmedkhan@gmail.com </h3>
                `
})
export class ContactComponent {
}