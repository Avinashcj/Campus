import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employeeService';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css'],
})
export class EmployeeDetailComponent implements OnInit {


  employees : Array<any>;
    
  constructor(public employeeService:EmployeeService){

  }
  ngOnInit(){
    this.employees = this.employeeService.getEmployees();
  }
}
