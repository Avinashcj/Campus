import { Injectable } from '@angular/core';

@Injectable()
export class EmployeeService
{
    constructor(){
        console.log("Employee service cons called");
    }
        getEmployees(){
            return [
      {"id": 1, "name": "Ahmed", gender: "Male"},
      {"id": 2, "name": "Rahul", gender: "Male"},
      {"id": 3, "name": "Neha", gender: "Female"},
      {"id": 4, "name": "Tarun", gender: "Male"},
  ]
        }
}
