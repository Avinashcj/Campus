import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employeeService'
@Component({
    selector : 'emp-comp',
    template : `<h1>Welcome to Employee Component</h1>
    <h2>Employee names List</h2>
    <ul *ngFor="let employee of employees">
            <li>{{employee.id}} - {{employee.name}} - {{ employee.gender}}</li>
    </ul>
   `,

})
export class EmployeeComponent implements OnInit
{
        userFromJSONAPI: User = JSON.parse('[{"lastName":"Nayrolles","firstName":"Mathieu"}]')[0]; 
        employees : Array<any>;
        e1 : Employee ; 
        e2 : Employee ;
        cust : Customer;
         constructor(public employeeService:EmployeeService){
        }
        ngOnInit(){
                
                this.cust = new Customer("A",90);
                this.e1 = Employee.getEmployeeObject();
                this.e2 = Employee.getEmployeeObject();
                 this.employees = this.employeeService.getEmployees();
                 console.log("%%%%%%%%%"+this.userFromJSONAPI);
        }







        message : string ="Welcome to EmployeeComponent";
        premiumCustomer : any;
       /*  constructor() {
          this.premiumCustomer = new PremiumCustomer("Nilesh",7600);
          //this.premiumCustomer = new PremiumCustomer("A");

        } */
        
        showCustomer(){
           this.message = this.premiumCustomer.show();
        }
}
class User{
        constructor(private lastName:string, private firstName:string){
        }
        hello(){
            console.log("Hi I am", this.firstName, this.lastName);
        }
    }
    

class Employee
{
        private static emp : Employee;
        private constructor(){
                console.log("####Employee class cons called");
        }
        static getEmployeeObject(){
                if (this.emp === null || this.emp == undefined)
                {
                        this.emp = new Employee();
                }

                return this.emp;
        }
}

class Customer
{
        customerName : string = "Tufail";
    billAmount : Number = 98000;

    constructor(customerName : string,billAmount : Number){
            this.customerName = customerName;
            this.billAmount = billAmount;
    }
    show(){
           
         return this.customerName+" is paying INR : "+this.billAmount
    }
}




interface IA
{

}
interface IB
{}
//
class PremiumCustomer extends Customer
{
    show(){
        return this.customerName+" is premium paying INR : "+this.billAmount
   }
}